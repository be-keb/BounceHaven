# VoxBound — standalone browser version

This is a browser-native JavaScript remake of the VoxBound Python/Pygame game. It does not need Pygame, Pygbag, Flask, or a build step. The game draws its graphics on an HTML canvas and uses the browser microphone through Web Audio.

## Run it locally

1. Keep `index.html`, `styles.css`, and `game.js` together in the same folder.
2. Open a terminal in this folder and run:

   ```bash
   python3 -m http.server 8000
   ```

3. Open `http://localhost:8000` in a current browser.
4. Press **Enable microphone** and allow access. Choose a difficulty with **1**, **2**, or **3**, or click a difficulty in the menu. Speak or make a sound to jump. Louder sounds produce stronger jumps.

Browsers normally allow microphone access on `localhost` and HTTPS websites. A plain remote `http://` site or a `file://` page may block microphone access. For GitHub Pages, upload all three files to the repository and enable Pages; it is served over HTTPS automatically.

## Controls and game behavior

- **1 / 2 / 3** or click: start Easy, Medium, or Hard.
- **Voice level**: jump and determine jump strength.
- **Esc**: return to the difficulty menu.
- The character runs forward automatically. Platforms bob up and down; successful landings add score and set a checkpoint. Falling starts a three-second respawn countdown.

Microphone audio is analyzed locally in the browser and is not recorded or uploaded by this game. The microphone permission button is optional for browsing the menu but required for voice jumps. A keyboard jump is intentionally not provided, matching the voice-only game design.

## Tune microphone sensitivity

In `game.js`, adjust `MIC_FLOOR`, `MIC_LOUD`, and `MIC_TRIGGER`. If normal speech fills the meter/jumps too strongly, raise `MIC_LOUD` or `MIC_TRIGGER`; if speaking does not register, lower them slightly. Browser and microphone gain settings vary by device.

The game artwork is drawn in JavaScript, so this folder has no separate image assets to install. The CSS requests Manrope and DM Mono from Google Fonts, but the browser falls back to local system fonts if those fonts are unavailable.
