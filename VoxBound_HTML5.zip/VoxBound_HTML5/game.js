(() => {
  'use strict';

  const W = 1280, H = 720;
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const micButton = document.getElementById('micButton');
  const micButtonText = document.getElementById('micButtonText');
  const micStatus = document.getElementById('micStatus');
  const micDot = document.getElementById('micDot');
  const announcement = document.getElementById('announcement');

  const CFG = {
    Easy: { gap: 120, width: 150, heightChange: [-15, 15], accent: '#9be9a4' },
    Medium: { gap: 150, width: 130, heightChange: [-22, 22], accent: '#ffdc7d' },
    Hard: { gap: 180, width: 115, heightChange: [-28, 28], accent: '#ff9787' }
  };
  const PLAYER = 70, PLATFORM_H = 28;
  const MIN_Y = 350, MAX_Y = 540, BOB = 18, BOB_SPEED = 1.6;
  const GRAVITY = 1200, RUN_SPEED = 300, RESPAWN_MS = 3000;
  const MIC_FLOOR = 0.002, MIC_LOUD = 0.05, MIC_TRIGGER = 0.06;
  const MIN_JUMP = 420, MAX_JUMP = 820, MIC_SMOOTHING = 0.22, COOLDOWN_MS = 350;

  let state = 'menu', difficulty = 'Easy', platforms = [], gameTime = 0;
  let playerX = 0, playerY = 0, velocityY = 0, onGround = false;
  let cameraX = 0, respawnX = 0, checkpoint = null, deathAt = 0;
  let score = 0, scored = new Set(), voiceRaw = 0, voiceSmoothed = 0, lastJumpAt = -COOLDOWN_MS;
  let audioContext = null, analyser = null, micStream = null, micData = null;
  let lastFrame = performance.now(), backgroundStars = [];
  let rng = Math.random;

  // Fixed, decorative star locations; they move at different parallax speeds.
  let starSeed = 74123;
  const starRandom = () => { starSeed = (starSeed * 16807) % 2147483647; return (starSeed - 1) / 2147483646; };
  for (let i = 0; i < 150; i++) backgroundStars.push({ x: starRandom() * 2400, y: starRandom() * H, r: .5 + starRandom() * 1.8, a: .2 + starRandom() * .65, p: .04 + starRandom() * .20 });

  function announce(text) { announcement.textContent = text; }
  function setMicStatus(text, enabled = false) {
    micStatus.textContent = text;
    micDot.classList.toggle('on', enabled);
    micButton.classList.toggle('is-on', enabled);
    micButton.setAttribute('aria-pressed', String(enabled));
    micButtonText.textContent = enabled ? 'Microphone on' : 'Enable microphone';
  }
  function seededRandom(seed) {
    let a = seed >>> 0;
    return () => { a += 0x6D2B79F5; let t = a; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  }
  function nextPlatform() {
    const cfg = CFG[difficulty], prev = platforms[platforms.length - 1];
    const change = Math.floor(rng() * (cfg.heightChange[1] - cfg.heightChange[0] + 1)) + cfg.heightChange[0];
    const y = Math.max(MIN_Y + BOB, Math.min(MAX_Y - BOB, prev.baseY + change));
    const p = { x: prev.x + prev.w + cfg.gap, y, baseY: y, w: cfg.width, h: PLATFORM_H, phase: platforms.length * .9, id: platforms.length };
    platforms.push(p);
  }
  function startGame(level) {
    difficulty = level;
    const seed = (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
    rng = seededRandom(seed);
    platforms = []; gameTime = 0; voiceSmoothed = 0; voiceRaw = 0; score = 0; scored = new Set();
    lastJumpAt = -COOLDOWN_MS;
    const start = { x: 60, y: 540, baseY: 540, w: CFG[level].width, h: PLATFORM_H, phase: 0, id: 0 };
    platforms.push(start);
    for (let i = 0; i < 10; i++) nextPlatform();
    playerX = start.x + (start.w - PLAYER) / 2;
    playerY = start.y - PLAYER;
    velocityY = 0; onGround = true; cameraX = 0; respawnX = playerX; checkpoint = start;
    state = 'game';
    announce(`${level} difficulty selected. Make a sound to jump.`);
    if (!micStream) setMicStatus('Enable microphone to jump');
  }
  function respawn() {
    playerX = respawnX;
    if (checkpoint) playerY = checkpoint.y - PLAYER;
    velocityY = 0; onGround = true;
    cameraX = Math.max(0, playerX + PLAYER / 2 - W / 3);
    state = 'ready';
    announce('Respawned. Make a sound to jump again.');
  }
  function jump() {
    const effort = Math.max(0, Math.min(1, (voiceSmoothed - MIC_TRIGGER) / (1 - MIC_TRIGGER)));
    velocityY = -(MIN_JUMP + effort * (MAX_JUMP - MIN_JUMP));
    onGround = false; lastJumpAt = performance.now();
    state = 'game';
  }
  function readMicrophone(dt) {
    let target = 0;
    if (analyser && micData) {
      analyser.getFloatTimeDomainData(micData);
      let sum = 0;
      for (let i = 0; i < micData.length; i++) sum += micData[i] * micData[i];
      voiceRaw = Math.sqrt(sum / micData.length);
      target = Math.max(0, Math.min(1, (voiceRaw - MIC_FLOOR) / (MIC_LOUD - MIC_FLOOR)));
    }
    const alpha = 1 - Math.pow(1 - MIC_SMOOTHING, Math.min(dt * 60, 1));
    voiceSmoothed += (target - voiceSmoothed) * alpha;
  }
  async function enableMicrophone() {
    if (micStream) {
      try { micStream.getTracks().forEach(track => track.stop()); } catch (_) {}
      micStream = analyser = micData = null;
      if (audioContext) { try { await audioContext.close(); } catch (_) {} audioContext = null; }
      voiceSmoothed = 0;
      setMicStatus('Microphone is off', false);
      announce('Microphone turned off.');
      return;
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setMicStatus('Microphone needs HTTPS or localhost', false);
      announce('Microphone unavailable. Open this game over HTTPS or localhost.');
      return;
    }
    micButton.disabled = true;
    micButtonText.textContent = 'Requesting access…';
    try {
      micStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: false, autoGainControl: false } });
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
      await audioContext.resume();
      const source = audioContext.createMediaStreamSource(micStream);
      analyser = audioContext.createAnalyser();
      analyser.fftSize = 1024;
      source.connect(analyser);
      micData = new Float32Array(analyser.fftSize);
      setMicStatus('Microphone is on — make a sound to jump', true);
      announce('Microphone enabled. Make a sound to jump.');
    } catch (error) {
      micStream = null;
      const message = error && error.name === 'NotAllowedError' ? 'Microphone permission was denied' : 'Could not start microphone';
      setMicStatus(message, false);
      micButtonText.textContent = 'Try microphone again';
      announce(message + '. Check your browser site permissions.');
    } finally {
      micButton.disabled = false;
    }
  }
  micButton.addEventListener('click', enableMicrophone);

  function roundedRect(x, y, w, h, r, fill, stroke = null, lineWidth = 1) {
    ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fillStyle = fill; ctx.fill();
    if (stroke) { ctx.lineWidth = lineWidth; ctx.strokeStyle = stroke; ctx.stroke(); }
  }
  function text(str, x, y, size, color, weight = 700, align = 'center', tracking = 0) {
    ctx.save(); ctx.textAlign = align; ctx.textBaseline = 'middle'; ctx.fillStyle = color;
    ctx.font = `${weight} ${size}px Manrope, system-ui, sans-serif`;
    if (!tracking) ctx.fillText(str, x, y);
    else { let width = ctx.measureText(str).width + tracking * (str.length - 1); let px = x - (align === 'center' ? width / 2 : align === 'right' ? width : 0); for (const char of str) { ctx.fillText(char, px, y); px += ctx.measureText(char).width + tracking; } }
    ctx.restore();
  }
  function drawBackground() {
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#26142b'); g.addColorStop(.52, '#492538'); g.addColorStop(1, '#1c101f');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    let haze = ctx.createRadialGradient(W * .57 - cameraX * .018, H * .38, 20, W * .57 - cameraX * .018, H * .38, 670);
    haze.addColorStop(0, 'rgba(192, 97, 95, .23)'); haze.addColorStop(.55, 'rgba(115, 55, 98, .1)'); haze.addColorStop(1, 'rgba(20, 10, 25, 0)');
    ctx.fillStyle = haze; ctx.fillRect(0, 0, W, H);
    for (const s of backgroundStars) {
      let sx = ((s.x - cameraX * s.p) % 2400 + 2400) % 2400;
      if (sx > W) continue;
      ctx.globalAlpha = s.a * (.82 + .18 * Math.sin(gameTime * .9 + s.x));
      ctx.fillStyle = s.r > 1.8 ? '#ffd88e' : '#fff0dc';
      ctx.beginPath(); ctx.arc(sx, s.y, s.r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
    // Distant drifting ridgelines add depth without external image assets.
    for (let layer = 0; layer < 3; layer++) {
      const yBase = 425 + layer * 64, scroll = cameraX * (.10 + layer * .045);
      ctx.beginPath(); ctx.moveTo(0, H);
      for (let x = -80; x <= W + 100; x += 80) {
        const wx = x + scroll;
        const y = yBase + Math.sin(wx * .004 + layer) * 28 + Math.sin(wx * .011 + layer * 3) * 13;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(W, H); ctx.closePath();
      ctx.fillStyle = ['rgba(71,35,67,.24)','rgba(41,27,49,.38)','rgba(19,16,31,.57)'][layer]; ctx.fill();
    }
  }
  function drawPlatform(p) {
    const x = p.x - cameraX, y = p.y;
    if (x < -250 || x > W + 250) return;
    ctx.save();
    ctx.shadowColor = '#ffc26575'; ctx.shadowBlur = 16;
    const grad = ctx.createLinearGradient(x, y, x, y + p.h);
    grad.addColorStop(0, '#ffdb91'); grad.addColorStop(.22, '#c77b64'); grad.addColorStop(1, '#552d46');
    roundedRect(x, y, p.w, p.h, 8, grad, '#ffd68a', 1.5);
    ctx.shadowBlur = 0;
    ctx.fillStyle = 'rgba(255,245,209,.35)'; roundedRect(x + 9, y + 5, p.w - 18, 3, 2, 'rgba(255,245,209,.34)');
    ctx.restore();
  }
  function drawPlayer() {
    const x = playerX - cameraX + PLAYER / 2, y = playerY + PLAYER / 2;
    ctx.save();
    const pulse = 1 + Math.max(0, voiceSmoothed) * .12;
    ctx.shadowColor = '#ffd16f'; ctx.shadowBlur = 24 + voiceSmoothed * 24;
    const grad = ctx.createRadialGradient(x - 12, y - 16, 3, x, y, 41 * pulse);
    grad.addColorStop(0, '#fff3c4'); grad.addColorStop(.28, '#ffd16f'); grad.addColorStop(1, '#cf775d');
    ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(x, y, 28 * pulse, 0, Math.PI * 2); ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#351e32'; ctx.beginPath(); ctx.arc(x - 8, y - 3, 3, 0, Math.PI * 2); ctx.arc(x + 8, y - 3, 3, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#75404b'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y + 3, 8, .2, Math.PI - .2); ctx.stroke();
    // Small sound marks respond to microphone loudness.
    if (voiceSmoothed > .04) {
      ctx.globalAlpha = Math.min(.75, voiceSmoothed + .18); ctx.strokeStyle = '#ffe4a0'; ctx.lineWidth = 2;
      for (let i = 0; i < 3; i++) { const r = 39 + i * 8 + voiceSmoothed * 10; ctx.beginPath(); ctx.arc(x, y, r, -.8, .8); ctx.stroke(); }
    }
    ctx.restore();
  }
  function drawMeter() {
    const x = W - 260, y = 27, w = 220, h = 15;
    text('VOICE', x, y - 10, 12, '#f7e7d2', 800, 'left', 1.2);
    roundedRect(x, y, w, h, 8, 'rgba(23,14,25,.72)', 'rgba(255,239,211,.55)', 1);
    if (voiceSmoothed > 0.005) roundedRect(x + 2, y + 2, (w - 4) * voiceSmoothed, h - 4, 6, '#ffd16f');
  }
  function drawHUD() {
    roundedRect(20, 18, 330, 43, 12, 'rgba(30,17,30,.75)', 'rgba(255,222,170,.18)', 1);
    text(`${difficulty.toUpperCase()}   ·   SCORE ${score}`, 38, 40, 14, '#fff0da', 800, 'left', .7);
    drawMeter();
  }
  function drawMenu() {
    drawBackground();
    ctx.fillStyle = 'rgba(16,10,19,.28)'; ctx.fillRect(0, 0, W, H);
    const x = 310, y = 105, w = 660, h = 510;
    ctx.save(); ctx.shadowColor = '#ffb95124'; ctx.shadowBlur = 45;
    roundedRect(x, y, w, h, 28, 'rgba(31,18,25,.83)', 'rgba(255,209,111,.86)', 2);
    ctx.restore();
    text('VOXBOUND', W / 2, y + 82, 65, '#ffd16f', 800, 'center', 3);
    text('YOUR VOICE IS YOUR POWER', W / 2, y + 132, 15, '#e8c8bd', 700, 'center', 3);
    text('Choose your difficulty', W / 2, y + 182, 17, '#fff3df', 700, 'center', 1.1);
    const items = [ ['1', 'EASY', 'Gentle gaps · a little more room'], ['2', 'MEDIUM', 'A steady rhythm · wider leaps'], ['3', 'HARD', 'Longer gaps · precise timing'] ];
    items.forEach((item, i) => {
      const by = y + 213 + i * 72, bx = W / 2 - 228, bw = 456, bh = 58;
      roundedRect(bx, by, bw, bh, 14, 'rgba(255,255,255,.055)', `${CFG[['Easy','Medium','Hard'][i]].accent}99`, 1.5);
      roundedRect(bx + 13, by + 11, 36, 36, 10, `${CFG[['Easy','Medium','Hard'][i]].accent}24`, `${CFG[['Easy','Medium','Hard'][i]].accent}80`, 1);
      text(item[0], bx + 31, by + 29, 15, CFG[['Easy','Medium','Hard'][i]].accent, 800);
      text(item[1], bx + 69, by + 22, 16, '#fff4e3', 800, 'left', .8);
      text(item[2], bx + 69, by + 42, 11, '#bdaab0', 500, 'left');
    });
    text('Press 1, 2, or 3 to begin', W / 2, y + 455, 14, '#ead8c7', 600);
    text(micStream ? 'MICROPHONE READY  ·  MAKE A SOUND TO JUMP' : 'ENABLE YOUR MIC ABOVE TO PLAY WITH YOUR VOICE', W / 2, H - 30, 11, micStream ? '#92e0aa' : '#d4b58a', 700, 'center', 1.3);
  }
  function drawDeath() {
    drawBackground(); platforms.forEach(drawPlatform);
    text('VOICE RUN INTERRUPTED', W / 2, H / 2 - 45, 15, '#d9b7b3', 800, 'center', 2);
    const left = Math.max(0, Math.ceil((RESPAWN_MS - (performance.now() - deathAt)) / 1000));
    text(`RESTARTING IN ${left}`, W / 2, H / 2 + 8, 42, '#fff0da', 800, 'center', 1.2);
    text(`CHECKPOINT SCORE  ${score}`, W / 2, H / 2 + 62, 14, '#ffd16f', 700, 'center', 1);
  }
  function drawReady() {
    drawBackground(); platforms.forEach(drawPlatform); drawPlayer(); drawHUD();
    roundedRect(W / 2 - 245, 73, 490, 47, 13, 'rgba(30,17,30,.78)', 'rgba(255,209,111,.32)', 1);
    text('MAKE A SOUND TO JUMP AND RUN', W / 2, 96, 14, '#fff1dc', 800, 'center', 1);
  }
  function updateGame(dt, now) {
    const oldBottom = playerY + PLAYER;
    for (let i = 1; i < platforms.length; i++) {
      const p = platforms[i];
      p.y = Math.round(p.baseY + Math.sin(gameTime * BOB_SPEED + p.phase) * BOB);
    }
    while (platforms[platforms.length - 1].x + platforms[platforms.length - 1].w < cameraX + W + 500) nextPlatform();
    playerX += RUN_SPEED * dt;
    velocityY += GRAVITY * dt;
    playerY += velocityY * dt;
    const newBottom = playerY + PLAYER;
    onGround = false;
    if (velocityY >= 0) {
      for (const p of platforms) {
        const overlapX = playerX + PLAYER > p.x && playerX < p.x + p.w;
        const previousTop = p._previousY === undefined ? p.y : p._previousY;
        const crossed = oldBottom <= previousTop && newBottom >= p.y;
        if (overlapX && crossed) {
          playerY = p.y - PLAYER; velocityY = 0; onGround = true;
          respawnX = playerX; checkpoint = p;
          if (!scored.has(p.id)) { scored.add(p.id); score++; }
          break;
        }
      }
    }
    for (const p of platforms) p._previousY = p.y;
    cameraX = Math.max(0, playerX + PLAYER / 2 - W / 3);
    if (playerY > H + 100) { state = 'dead'; deathAt = now; announce(`Fell. Restarting in three seconds. Score ${score}.`); }
  }
  function frame(now) {
    const dt = Math.min((now - lastFrame) / 1000, 1 / 30);
    lastFrame = now;
    if (state !== 'menu' && state !== 'dead' && state !== 'ready') gameTime += dt;
    readMicrophone(dt);
    const voiceActive = voiceSmoothed >= MIC_TRIGGER;
    if (state === 'game' && onGround && voiceActive && now - lastJumpAt >= COOLDOWN_MS) jump();
    if (state === 'ready' && voiceActive && now - lastJumpAt >= COOLDOWN_MS) jump();

    if (state === 'menu') drawMenu();
    else if (state === 'dead') {
      drawDeath();
      if (now - deathAt >= RESPAWN_MS) respawn();
    } else if (state === 'ready') drawReady();
    else { updateGame(dt, now); drawBackground(); platforms.forEach(drawPlatform); drawPlayer(); drawHUD(); }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  function pointerToLogical(event) {
    const r = canvas.getBoundingClientRect();
    return { x: (event.clientX - r.left) * W / r.width, y: (event.clientY - r.top) * H / r.height };
  }
  canvas.addEventListener('click', event => {
    if (state !== 'menu') return;
    const p = pointerToLogical(event);
    if (p.x > 420 && p.x < 860 && p.y > 318 && p.y < 368) startGame('Easy');
    else if (p.x > 420 && p.x < 860 && p.y > 390 && p.y < 440) startGame('Medium');
    else if (p.x > 420 && p.x < 860 && p.y > 460 && p.y < 512) startGame('Hard');
  });
  window.addEventListener('keydown', event => {
    if (state === 'menu') {
      if (event.key === '1') startGame('Easy');
      if (event.key === '2') startGame('Medium');
      if (event.key === '3') startGame('Hard');
    } else if (event.key === 'Escape') {
      state = 'menu'; cameraX = 0; voiceSmoothed = 0; announce('Returned to the difficulty menu.');
    }
  });
  window.addEventListener('pagehide', () => {
    if (micStream) micStream.getTracks().forEach(track => track.stop());
    if (audioContext) audioContext.close();
  });
})();
